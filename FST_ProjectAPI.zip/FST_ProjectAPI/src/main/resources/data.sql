INSERT INTO users(id, first_name, last_name, email) VALUES
    (1, 'Hansel', '', 'hans@grimm.tales'),
    (2, 'Gretel', '', 'greta@grimm.tales');